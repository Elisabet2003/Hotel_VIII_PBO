package model;

import core.Core;
import entity.ReservasiEntity;


import java.util.ArrayList;

public class ReservasiModel {
    private static ArrayList<ReservasiEntity> reservasiArrayListt = Core.reservasiArrayList;
    public static ArrayList<ReservasiEntity> getListReservasi(){
        return reservasiArrayListt;
    }
    public static int addReservasi(ReservasiEntity reservasi){
        int status = -1;
        if (reservasi == null){
            status = 0;
        }
        else {
            Core.reservasiArrayList.add(reservasi);
            status = 1;
        }
        return status;
    }
}
