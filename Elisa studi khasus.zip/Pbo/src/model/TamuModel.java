package model;

import java.util.*;
import core.Core;
import entity.*;

public class TamuModel {
    private static ArrayList<TamuEntity> tamuEntityArrayList = Core.tamuEntityArrayList;

    public static ArrayList<TamuEntity> getTamuList() {
        return tamuEntityArrayList;
    }

    public static int addTamu(TamuEntity tamu) {
        int status = -1;
        if (tamu == null) {
            status = 0;
        } else {
            Core.tamuEntityArrayList.add(tamu);
            status = 1;
        }
        return status;
    }
    public static int updateNamaTamu(int idTamu, String namaTamu) {
        int index = getIndexTamu(idTamu);
        Core.tamuEntityArrayList.get(index).setNama(namaTamu);
        return index;
    }


    public static int updateAlamatTamu(int idTamu , String alamatTamu) {
        int index = getIndexTamu(idTamu);
        Core.tamuEntityArrayList.get(index).setAlamatTamu(alamatTamu);
        return index;
    }
    public static int updateStatus(int idTamu, boolean status){
        int index = getIndexTamu(idTamu);
        Core.tamuEntityArrayList.get(index).setStatus(status);
        return index;
    }

    public static int getIndexTamu(int idTamu) {
        int index = -1;
        if (tamuEntityArrayList.isEmpty()) {
            System.err.println("DATA KOSONG");
            System.out.println("");
        } else {
            for (TamuEntity tamu : tamuEntityArrayList) {
                if (tamu.getIdTamu()==idTamu) {
                    index = tamuEntityArrayList.indexOf(tamu);
                }
            }
        }
        return index;
    }

    public static int removeTamu(int idTamu) {
        int index = getIndexTamu(idTamu);
        if (index != -1) {
            tamuEntityArrayList.remove(index);
        }
        return index;
    }
}