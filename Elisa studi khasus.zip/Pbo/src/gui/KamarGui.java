package gui;

import core.Core;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.util.ArrayList;
import controller.KamarController;
import entity.KamarEntity;

import java.awt.Color;
import java.awt.Font;

public class KamarGui extends Frame{
    private JLabel hotelLabel,tipeKamarJLabel,nomerKamarLabel,hargaLabel,idKamarLabel;
    private JTextField tipeField,nomerField,hargaField,idKamarField;
    private JButton saveButton,editButton,hapusButton,keluarButton;
    private JLabel imageLogin;
    private JTable kamarTable;
    private JScrollPane scrollPane;

    public KamarGui() {
        super("LOGIN", 1200, 700);
        setLocation(250, 50);
        getContentPane().setBackground(Color.CYAN);
    }

    @Override
    protected void component() {
        imageLogin = new JLabel(loadImage("src/assets/masSando.jpg", 200, 200));
        boundedAdd(imageLogin, 100, 62, 200, 200);

        hotelLabel = new JLabel("HOTEL MELATI");
        hotelLabel.setFont(new Font("Arial", Font.BOLD, 24));
        hotelLabel.setForeground(color("#2596be"));
        boundedAdd(hotelLabel, 100, 265, 200, 45);

        tipeKamarJLabel = new JLabel("TIPE KAMAR");
        tipeKamarJLabel.setFont(new Font("Arial", Font.BOLD, 13));
        boundedAdd(tipeKamarJLabel, 65, 320, 100, 18);

        tipeField = new JTextField();
        boundedAdd(tipeField, 65, 340, 250, 30);

        nomerKamarLabel = new JLabel("NOMER KAMAR");
        nomerKamarLabel.setFont(new Font("Arial", Font.BOLD, 13));
        boundedAdd(nomerKamarLabel, 65, 390, 100, 18);

        nomerField = new JTextField();
        boundedAdd(nomerField, 65, 410, 250, 30);

        hargaLabel = new JLabel("HARGA KAMAR");
        hargaLabel.setFont(new Font("Arial", Font.BOLD, 13));
        boundedAdd(hargaLabel, 65, 460, 100, 18);

        hargaField = new JTextField();
        boundedAdd(hargaField, 65, 480, 250, 30);

        idKamarLabel = new JLabel("ID KAMAR");
        idKamarLabel.setFont(new Font("Arial", Font.BOLD, 13));
        boundedAdd(idKamarLabel, 65, 530, 100, 18);

        idKamarField = new JTextField();
        boundedAdd(idKamarField, 65, 550, 250, 30);

        kamarTable = new JTable();
        kamarTable.setModel(createDataTable());
        kamarTable.setEnabled(false);
        kamarTable.getTableHeader().setReorderingAllowed(false);
        scrollPane = new JScrollPane(kamarTable);
        boundedAdd(scrollPane, 350, 72, 745, 440);

        editButton = new JButton("EDIT");
        editButton.setForeground(Color.white);
        editButton.setBackground(color("#2596be"));
        editButton.setFocusPainted(false);
        boundedAdd(editButton, 165, 600, 85, 30);

        hapusButton = new JButton("HAPUS");
        hapusButton.setForeground(Color.white);
        hapusButton.setBackground(color("#2596be"));
        hapusButton.setFocusPainted(false);
        boundedAdd(hapusButton, 265, 600, 85, 30);

        keluarButton = new JButton("KELUAR");
        keluarButton.setForeground(Color.white);
        keluarButton.setBackground(color("#2596be"));
        keluarButton.setFocusPainted(false);
        boundedAdd(keluarButton, 365, 600, 85, 30);

        saveButton = new JButton("SAVE");
        saveButton.setForeground(Color.white);
        saveButton.setBackground(color("#2596be"));
        saveButton.setFocusPainted(false);
        boundedAdd(saveButton, 65, 600, 85, 30);
    }

    @Override
    protected void event() {
        saveButton.addActionListener((e) -> {
            try {
                String TipeKamar = tipeField.getText();
                String nomerKamar = nomerField.getText();
                int hargaKamar = Integer.parseInt(hargaField.getText());
                int idKamar = Integer.parseInt(idKamarField.getText());

                KamarController kamar = new KamarController();
                kamar.addKamar(TipeKamar, nomerKamar, hargaKamar, idKamar);
                JOptionPane.showMessageDialog(null, "SUKSES TAMBAH", "Sukses",
                                JOptionPane.INFORMATION_MESSAGE);
                                dispose();
                                new KamarGui().setVisible(true);
            } catch (Exception er) {
                JOptionPane.showMessageDialog(null, "Harga Atau Id Harus Angka", "Gagal",
                            JOptionPane.ERROR_MESSAGE);
                            dispose();
                            new KamarGui().setVisible(true);
            }
        });

        editButton.addActionListener((e) -> {
            try {
                String nomerKamar = nomerField.getText();
                int idKamar = Integer.parseInt(idKamarField.getText());

                KamarController kamar = new KamarController();
                int index = kamar.getIndexKamar(idKamar);
                if(index>=0){
                    kamar.updateNomer(idKamar, nomerKamar);
                    JOptionPane.showMessageDialog(null, "SUKSES EDIT", "Sukses",
                                JOptionPane.INFORMATION_MESSAGE);
                                dispose();
                                new KamarGui().setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null, "DATA TIDAK DITEMUKAN", "Gagal",
                            JOptionPane.ERROR_MESSAGE);
                            dispose();
                            new KamarGui().setVisible(true);
                }
            } catch (Exception er) {
                JOptionPane.showMessageDialog(null, "Id Harus Angka", "Gagal",
                            JOptionPane.ERROR_MESSAGE);
                            dispose();
                            new KamarGui().setVisible(true);
            }
        });

        hapusButton.addActionListener((e) -> {
            try {
                int idKamar = Integer.parseInt(idKamarField.getText());

                KamarController kamar = new KamarController();
                int index = kamar.getIndexKamar(idKamar);
                if(index>=0){
                    kamar.removeKamar(idKamar);
                    JOptionPane.showMessageDialog(null, "SUKSES HAPUS", "Sukses",
                                JOptionPane.INFORMATION_MESSAGE);
                                dispose();
                                new KamarGui().setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null, "DATA TIDAK DITEMUKAN", "Gagal",
                            JOptionPane.ERROR_MESSAGE);
                            dispose();
                            new KamarGui().setVisible(true);
                }
            } catch (Exception er) {
                JOptionPane.showMessageDialog(null, "Id Harus Angka", "Gagal",
                            JOptionPane.ERROR_MESSAGE);
                            dispose();
                            new KamarGui().setVisible(true);
            }
        });

        keluarButton.addActionListener((e)->{
            dispose();
            new MenuGui().setVisible(true);
        });

    }

    private DefaultTableModel createDataTable() {
        DefaultTableModel dataTable = new DefaultTableModel();
        Object column[] = {
                "TIPE KAMAR",
                "NO KAMAR",
                "HARGA",
                "ID KAMAR",
        };
        dataTable.setColumnIdentifiers(column);

        ArrayList<KamarEntity> kamar = Core.kamarEntityArrayList;

        for (KamarEntity objek : kamar) {
            Object[] data = new String[] {
                  objek.getTipeKamar(),objek.getNomerKamar(),String.valueOf(objek.getHargaKamar()) ,String.valueOf(objek.getIdKamar())
            };

            dataTable.addRow(data);
        }
        return dataTable;
    }
}
