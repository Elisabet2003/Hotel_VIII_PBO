package controller;

import entity.StaffEntity;
import model.StaffModel;

import java.util.ArrayList;

public class StaffController implements StaffInterface {
    public ArrayList<StaffEntity> getListStaff(){
        return StaffModel.getListStaff();
    }
    public int addStaff(StaffEntity staff){
        int status = StaffModel.addStaff(staff);
        return status;
    }

    public StaffEntity cari(int idStaff,String password){
        return StaffModel.cari(idStaff, password);
    }

    public int getIndexStaff(int idStaff){
        return StaffModel.getIndexStaff(idStaff);
    }
    public int updateNamaStaff(int idStaff, String namaStaff){
        return StaffModel.updateNamaStaff(idStaff, namaStaff);
    }
    public int updatePassStaff(int idStaff, String passStaff){
        return StaffModel.updatePassStaff(idStaff,passStaff);
    }
    public int removeStaff(int idStaff){
        return StaffModel.removeStaff(idStaff);
    }

    @Override
    public void output() {

    }
}
