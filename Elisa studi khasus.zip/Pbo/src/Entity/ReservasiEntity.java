package Entity;

public class ReservasiEntity {
    private String namaTamu;
    private String nomerKamar;

    public ReservasiEntity(String namaTamu, String nomerKamar) {
        this.namaTamu = namaTamu;
        this.nomerKamar = nomerKamar;
    }

    public String getNamaTamu() {
        return namaTamu;
    }

    public void setNamaTamu(String namaTamu) {
        this.namaTamu = namaTamu;
    }

    public String getNomerKamar() {
        return nomerKamar;
    }

    public void setNomerKamar(String nomerKamar) {
        this.nomerKamar = nomerKamar;
    }
}
