package Entity;

public class KamarEntity {

    private String TipeKamar;
    private String nomerKamar;
    private int hargaKamar;
    private int idKamar;

    public KamarEntity(String TipeKamar, String nomerKamar, int hargaKamar, int idKamar) {
        this.TipeKamar = TipeKamar;
        this.nomerKamar = nomerKamar;
        this.hargaKamar = hargaKamar;
        this.idKamar = idKamar;
    }

    public String getTipeKamar() {
        return TipeKamar;
    }

    public void setTipeKamar(String TipeKamar) {
        this.TipeKamar = TipeKamar;
    }

    public String getNomerKamar() {
        return nomerKamar;
    }

    public void setNomerKamar(String nomerKamar) {
        this.nomerKamar = nomerKamar;
    }

    public int getHargaKamar() {
        return hargaKamar;
    }

    public void setHargaKamar(int hargaKamar) {
        this.hargaKamar = hargaKamar;
    }

    public int getIdKamar() {
        return idKamar;
    }

    public void setIdKamar(int idKamar) {
        this.idKamar = idKamar;
    }
}
