package Entity;

public class TamuEntity extends UserEntity {

    private String alamatTamu;
    private int idTamu;
    private boolean status;

    public TamuEntity(String nama, String alamatTamu, int idTamu, boolean status) {
        super(nama);
        this.alamatTamu = alamatTamu;
        this.idTamu = idTamu;
        this.status = status;
    }

    public String getAlamatTamu() {
        return alamatTamu;
    }

    public void setAlamatTamu(String alamatTamu) {
        this.alamatTamu = alamatTamu;
    }

    public int getIdTamu() {
        return idTamu;
    }

    public void setIdTamu(int idTamu) {
        this.idTamu = idTamu;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}