package Entity;

public class StaffEntity extends UserEntity{

    private int idStaff;

    public StaffEntity(String nama, String password, int idStaff) {
        super(nama,password);
        this.idStaff = idStaff;
    }
    public int getIdStaff(){
        return idStaff;
    }
    public void setId(int idCard){
        this.idStaff =idCard;
    }
}
