package view;// package view;

// import java.util.Scanner;

// public class MainMenu {
//     public void menu(){
//         char lanjut;
//         Scanner keyboard    = new Scanner(System.in);
//         TamuView tamuView   = new TamuView();
//         KamarView kamarView = new KamarView();
//         StaffView staffView = new StaffView();
//         int pilih;

//         do {
//             System.out.println("pilih menu :");
//             System.out.println("1. Tamu");
//             System.out.println("2. Kamar");
//             System.out.println("3. Reservasi");
//             System.out.println("4. EXIT");
//             System.out.print("Pilih : ");
//             pilih = keyboard.nextInt();
//             switch (pilih) {
//                 case 1 :
//                     tamuView.tamuView();
//                     break;
//                 case 2 :
//                     kamarView.kamarView();
//                     break;
//                 case 3:
//                     staffView.staffView();
//                     break;
//                 case 4:
//                     System.out.println("EXIT");
//                     break;
//                 default:
//                     System.out.println("Pilihan Tidak Ada");
//                     break;
//             }
//         } while (pilih != 4);
//         }
//     }
