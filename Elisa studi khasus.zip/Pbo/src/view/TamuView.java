package view;// package view;


// import controller.TamuController;
// import entity.TamuEntity;
// import model.TamuModel;
// import java.util.*;

// import static core.Core.tamuEntityArrayList;


// public class TamuView {
//     TamuModel tamuModel = new TamuModel();
//     TamuController tamuController = new TamuController();

//     public void tamuView(){
//         Scanner keyboard = new Scanner(System.in);
//         int pilih;
//         System.out.println("1. Tambah Tamu");
//         System.out.println("2. Tampil Tamu");
//         System.out.println("3. Update Tamu");
//         System.out.println("4. Hapus Tamu");
//         System.out.println("5. exit");
//         System.out.print("Pilih : ");
//         pilih = keyboard.nextInt();
//         switch (pilih) {
//             case 1:
//                 inputTamu();
//                 break;
//             case 2:
//                 viewTamu();
//                 break;
//             case 3:
//                 updateTamu();
//                 break;
//             case 4:
//                 hapusTamu();
//                 break;
//             case 5 :
//                 System.out.println("EXIT");
//                 break;
//             default:
//                 System.out.println("Pilihan Tidak Ada");
//                 break;
//         }
//     }
//     public void viewTamu(){
//         ArrayList<TamuEntity> tamuEntities = tamuController.getlistTamu();
//         if (tamuEntityArrayList.isEmpty()){
//             System.err.println("DATA KOSONG");
//             System.out.println("");
//         }else {
//             for (TamuEntity tamu : tamuEntities) {
//                 System.out.println("Nama Tamu : " + tamu.getNama());
//                 System.out.println("Alamat Tamu : " + tamu.getAlamatTamu());
//                 System.out.println("Id Tamu : "+ tamu.getIdTamu());
//                 System.out.println("Status Tamu : "+ tamu.isStatus());
//                 System.out.println("");
//             }
//         }
//     }

//     public void inputTamu(){
//         Scanner input = new Scanner(System.in);
//         System.out.print("Masukkan Nama Tamu : ");
//         String namaTamu = input.nextLine();
//         System.out.print("Masukkan Alamat Tamu: ");
//         String alamatTamu = input.nextLine();
//         System.out.print("Masukkan Id Tamu: ");
//         int idTamu = input.nextInt();
//         System.out.print("Masukkan Status Tamu : ");
//         boolean statusTamu = input.nextBoolean();
//         int status = tamuController.addStaff(new TamuEntity(namaTamu, alamatTamu, idTamu,statusTamu));
//         if (status == 0){
//             System.out.println("DATA GAGAL DIINPUTKAN");
//         }
//         else if (status == 1){
//             System.out.println("DATA BERHASIL DIINPUTKAN");
//         }
//         else {
//             System.out.println("INPUT ERROR");
//         }

//     }
//     public void updateTamu() {
//         ArrayList<TamuEntity> tamuEntities = tamuController.getlistTamu();
//         Scanner input = new Scanner(System.in);
//         if (tamuEntities.isEmpty()) {
//             System.err.println("Data Tidak Ada");
//             System.out.println("");
//         } else {
//             System.out.print("Id Tamu : ");
//             int idTamu = input.nextInt();
//             int indeks =  tamuController.getIndexTamu(idTamu);
//             if (indeks != -1) {
//                 System.out.println("Mana yang Diupdate : ");
//                 System.out.println("1. Nama Tamu : ");
//                 System.out.println("2. Alamat Tamu :");
//                 System.out.println("3. Status Tamu");
//                 System.out.print("Pilih : ");
//                 int pilih = input.nextInt();
//                 input.nextLine();
//                 switch (pilih) {
//                     case 1:
//                         System.out.print("Nama Tamu Baru : ");
//                         String namaTamuBaru = input.nextLine();
//                         tamuController.updateNamaTamu(idTamu,namaTamuBaru);
//                         break;
//                     case 2:
//                         System.out.print("Alamat Tamu Baru : ");
//                         String alamatTamuBaru = input.nextLine();
//                         tamuController.updateAlamatTamu(idTamu,alamatTamuBaru);
//                         break;
//                     case 3:
//                         System.out.print("Status Baru");
//                         boolean status = input.nextBoolean();
//                         tamuController.updatePassword(idTamu,status);
//                         break;
//                 }
//             }else{
//                 System.out.println("TIDAK TERDAFTAR");
//             }
//         }
//     }
//     public void hapusTamu() {
//         ArrayList<TamuEntity> tamuEntities = tamuController.getlistTamu();
//         Scanner input = new Scanner(System.in);
//         int tamu ;
//         if (tamuEntities.isEmpty()) {
//             System.out.println("Data Tidak Ada");
//             System.out.println("--------");
//         } else {
//             System.out.print("Id Tamu Yang Ingin Dihapus : ");
//             tamu = input.nextInt();
//             int indeks = tamuController.removeTamu(tamu);
//             if (indeks == -1){
//                 System.out.println("DATA YANG DIHAPUS TIDAK DITEMUKAN");
//             }
//             else {
//                 System.out.println("DATA INDEX - " + indeks + 1 + " TELAH DIHAPUS");
//             }
//         }
//     }
// }

